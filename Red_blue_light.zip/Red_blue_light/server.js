
const express = require("express");
const bodyParser = require("body-parser");
const app = express();
const http = require("http").Server(app);
const io = require("socket.io")(http);

let message = "blue";

app.use(express.static("./webb"));

app.use(bodyParser.urlencoded({ extended: false }));

app.get("/meddelanden", (req, res) => {
    res.send(message);
});

app.post("/meddelanden", (req, res) => {
    message = req.body.message
    res.sendStatus(200)
});

io.on("connection", (socket) => {
    console.log("En användare anslöt")
    socket.on("disconnect", () => {
        console.log("Användaren kopplade från")
    });
});

http.listen(3000, () => {
    console.log("Servern körs, besök http://localhost:3000");
});